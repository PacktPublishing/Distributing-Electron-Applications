module.exports = require('bindings')('HelloWorld');
