#ifndef NATIVE_HELLO_WORLD_H
#define NATIVE_HELLO_WORLD_H

#include <nan.h>

NAN_METHOD(GetString);

#endif
